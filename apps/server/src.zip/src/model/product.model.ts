export type Product = {
    name: string,
    description: string | null
}