import { PrismaClient } from "../../../../packages/database/prisma/prisma-client";
export const prisma = new PrismaClient();